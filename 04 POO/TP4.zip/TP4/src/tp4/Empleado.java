package tp4;


public class Empleado {

    private int idEmpleado;
    private String nombre;
    private String puesto;
    private double salario;
    private static int contadorEmpleados = 0;

    public Empleado(int idEmpleado, String nombre, String puesto, double salario) {
        this.idEmpleado = idEmpleado;
        this.nombre = nombre;
        this.puesto = puesto;
        this.salario = salario;
        contadorEmpleados += 1;
    }

    public Empleado(String nombre, String puesto) {
        this.nombre = nombre;
        this.puesto = puesto;
        this.idEmpleado = 21354;
        this.salario = 2000;
        contadorEmpleados += 1;
    }

    public double actualizarSalario(int porcentajeAumento) {
        return this.salario = this.salario * (1 + porcentajeAumento / 100.00);
    }

    public double acualizarSalario(double cantidadAumento) {
        return this.salario = this.salario + cantidadAumento;
    }

    @Override
    public String toString() {
        return "Empleado{" + "ID Empleado=" + idEmpleado + ", nombre=" + nombre + ", puesto=" + puesto + ", salario=" + salario + '}';
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public static int getContadorEmpleados() {
        return contadorEmpleados;
    }

}
