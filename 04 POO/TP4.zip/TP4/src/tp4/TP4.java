package tp4;



public class TP4 {

    public static void main(String[] args) {
        Empleado emp1 = new Empleado(235, "Jorge", "administrativo", 1500);
        Empleado emp2 = new Empleado("Raul", "mantenimiento");

        System.out.println("Empleado 1\n" + emp1);
        System.out.println("Empleado 2\n" + emp2);
        System.out.println("");
        
        emp1.actualizarSalario(50);
        emp2.acualizarSalario(1800);
        
        System.out.println("Empleado 1 sueldo actualizado\n" + emp1);
        System.out.println("Empleado 2 sueldo actualizado\n" + emp2);
        
        System.out.println("Total empleados: " + Empleado.getContadorEmpleados());

    }
}
